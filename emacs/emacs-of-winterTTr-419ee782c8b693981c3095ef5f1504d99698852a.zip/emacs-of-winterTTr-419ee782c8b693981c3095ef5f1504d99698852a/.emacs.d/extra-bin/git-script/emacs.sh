#! /bin/sh
HOME=/e/Tools/Emacs;/e/Tools/Emacs/bin/emacsclientw.exe $1
